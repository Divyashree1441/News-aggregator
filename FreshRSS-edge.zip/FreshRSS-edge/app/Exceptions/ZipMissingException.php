<?php
declare(strict_types=1);

class FreshRSS_ZipMissing_Exception extends Minz_Exception {
}
