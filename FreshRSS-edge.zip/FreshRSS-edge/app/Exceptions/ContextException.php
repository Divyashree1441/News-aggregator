<?php
declare(strict_types=1);

/**
 * An exception raised when a context is invalid
 */
class FreshRSS_Context_Exception extends Minz_Exception {

}
