<?php
declare(strict_types=1);

class FreshRSS_Feed_Exception extends Minz_Exception {

}
