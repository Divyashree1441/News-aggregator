<?php
declare(strict_types=1);

class FreshRSS_EntriesGetter_Exception extends Minz_Exception {

}
