<?php
declare(strict_types=1);

class FreshRSS_Days {
	public const TODAY = 0;
	public const YESTERDAY = 1;
	public const BEFORE_YESTERDAY = 2;
}
