List of canonical URLS of the various feeds users have subscribed to.
Several users can have subscribed to the same feed.

* ./base64url(canonicalUrl)/
	* ./!hub.json
	* ./user1.txt
	* ./user2.txt
