# Security Policy

## Reporting a Vulnerability

Draft a [new security advisory](https://github.com/FreshRSS/FreshRSS/security/advisories) online,
or report security issues to <alexandre@alapetite.fr> ([PGP public key if relevant](https://alexandre.alapetite.fr/cv/pgp.asc)).
