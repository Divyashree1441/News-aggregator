<?php
declare(strict_types=1);

header('Location: p/', true, 301);
include('index.html');
