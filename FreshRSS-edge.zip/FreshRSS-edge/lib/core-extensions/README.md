# FreshRSS core extensions

This directory contains some core extensions shipped with FreshRSS.

For custom third-party extensions, use the `./FreshRSS/extensions/` directory instead.
