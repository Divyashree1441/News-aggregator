<?php

return array(
	'user_css' => array(
		'write_css' => 'Benutzerspezifische CSS Regeln',
	),
);
