<?php

return array(
	'user_css' => array(
		'write_css' => '追加のCSSルール',
	),
);
