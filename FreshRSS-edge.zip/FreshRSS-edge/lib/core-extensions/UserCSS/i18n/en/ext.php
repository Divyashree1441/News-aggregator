<?php

return array(
	'user_css' => array(
		'write_css' => 'Additional CSS rules',
	),
);
