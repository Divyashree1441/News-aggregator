<?php

return array(
	'user_css' => array(
		'write_css' => 'Règles CSS supplémentaires',
	),
);
