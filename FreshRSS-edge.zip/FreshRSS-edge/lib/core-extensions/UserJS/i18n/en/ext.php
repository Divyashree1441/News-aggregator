<?php

return array(
	'user_js' => array(
		'write_js' => 'Additional JS',
	),
);
