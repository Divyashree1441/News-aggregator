<?php

return array(
	'user_js' => array(
		'write_js' => '追加のJS',
	),
);
