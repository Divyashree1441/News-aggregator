<?php

return array(
	'user_js' => array(
		'write_js' => 'Benutzerspezifische Javascript Regeln',
	),
);
