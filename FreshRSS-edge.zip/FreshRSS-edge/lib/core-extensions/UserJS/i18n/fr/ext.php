<?php

return array(
	'user_js' => array(
		'write_js' => 'JS supplémentaires',
	),
);
