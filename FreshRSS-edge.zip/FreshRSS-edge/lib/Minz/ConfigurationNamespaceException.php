<?php
declare(strict_types=1);

class Minz_ConfigurationNamespaceException extends Minz_ConfigurationException {
}
