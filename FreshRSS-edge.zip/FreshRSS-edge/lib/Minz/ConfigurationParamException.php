<?php
declare(strict_types=1);

class Minz_ConfigurationParamException extends Minz_ConfigurationException {
}
