# Migration

see [English documentation](/docs/en/developers/Minz/migrations.md)
