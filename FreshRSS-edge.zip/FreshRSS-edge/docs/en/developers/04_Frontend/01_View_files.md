# View files

## The .phtml files

> **TODO**

## Writing a URL

> **TODO**

## Displaying an icon

> **TODO**

## Internationalisation

> **TODO**
